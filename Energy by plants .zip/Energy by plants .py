Notas = []

while True:
    num = int(input("Ingrese sus notas(o 0 si desea terminar.)"))

    if num == 0:
        break

    Notas.append(num)

print("Lista de sus Notas ingresadas:")

for n in Notas:
    print(n)

print("Clasificacion de las notas:")
for n in Notas:
    if n > 69:
        print(n, "Bien hecho")
    else:
        print(n, "Me has decepsionado...")

print("Numero de Notas:")
print(len(Notas))
print("       ")
print("Suma de todas las notas:")
print(sum(Notas))
print("       ")
print("Nota mas baja:")
print(min(Notas))
print("       ")
print("Nota mas alta:")
print(max(Notas))